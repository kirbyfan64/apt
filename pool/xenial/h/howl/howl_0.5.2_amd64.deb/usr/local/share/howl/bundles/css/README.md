# CSS mode

## What is it?

This is a CSS mode for the Howl editor. It features syntax highlighting, as well as
smart completion of properties and property values.

## Thanks

To http://css-infos.net for providing the compiled CSS property information used for completions.

## License

Please see LICENSE.md.