# Nim bundle

## What is it?

This is a Nim bundle for the Howl editor, providing Nim specific lexing
and a Nim mode.

## License

Copyright 2015 The Howl Developers
License: MIT (see LICENSE.md at the top-level directory of the distribution)
