# Pascal bundle

## What is it?

This is a Pascal bundle for the Howl editor, providing Pascal specific lexing
and a Pascal mode. It is designed to target the Free Pascal dialect, but it should
also support Standard Pascal, Turbo Pascal, and Delphi.

## License

Copyright 2016 The Howl Developers
License: MIT (see LICENSE.md at the top-level directory of the distribution)
