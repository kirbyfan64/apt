# Ruby bundle

## What is it?

This is a Ruby bundle for the Howl editor, currently containing a Ruby mode.

The mode provides Ruby specific lexing, as well as indentation support.

## License

Please see LICENSE
