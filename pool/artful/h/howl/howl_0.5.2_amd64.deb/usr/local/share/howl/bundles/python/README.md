# Python bundle

## What is it?

This is a Python bundle for the Howl editor, providing Python specific lexing
and a Python mode.

## License

Copyright 2012-2015 The Howl Developers
License: MIT (see LICENSE.md at the top-level directory of the distribution)
