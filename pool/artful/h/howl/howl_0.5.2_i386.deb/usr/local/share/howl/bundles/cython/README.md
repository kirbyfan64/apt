# Cython bundle

## What is it?

This is a [Cython](http://cython.org) bundle for the Howl editor, providing
Cython specific lexing and a Cython mode. It is automatically enabled for
Cython extensions such as `pyx` and `pxd`.

## License

Copyright 2017 The Howl Developers
License: MIT (see LICENSE.md at the top-level directory of the distribution)
